package com.tikalk;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;

import org.apache.axis2.AxisFault;
import org.apache.axis2.description.AxisService;
import org.apache.axis2.transport.http.AxisServlet;

public class MyAxisServlet extends AxisServlet {
@Override
public void init(ServletConfig config) throws ServletException {
	super.init(config);
	
	try {
		AxisService service = AxisService.createService("com.tikalk.CalcService", axisConfiguration);
		service.setDocumentation("Description goes here");
		axisConfiguration.addService(service);
	} catch (AxisFault e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}
