/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.tikalk;


/**
 *
 * @author andrew
 */
@javax.jws.WebService
public class CalcService {
    
    public int add (int a, int b) {
        return a+b;
    }
}
