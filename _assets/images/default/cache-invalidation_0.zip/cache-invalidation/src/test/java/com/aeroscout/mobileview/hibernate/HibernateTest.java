package com.aeroscout.mobileview.hibernate;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;
import org.hibernate.classic.Session;
import org.junit.Test;

import com.tikal.sample.model.Person;

public class HibernateTest {
	private SessionFactory sessionFactory;

	{
		Configuration cfg = new AnnotationConfiguration().configure("hibernate/hibernate.cfg.xml");
		cfg.setProperty("hibernate.current_session_context_class", "thread");
		sessionFactory = cfg.buildSessionFactory();
	}

	private Session currentSession() {
		return sessionFactory.getCurrentSession();
	}

	// test the saving a person
	@Test
	public void testCache() {
		Person parent = new Person("parent");
		createParent(parent);
		loadParentAndChildrenIntoCache(parent);
		addNewChild(parent);
		assertCacheNotStale(parent);
	}

	private void assertCacheNotStale(Person parent) {
		try {
			currentSession().beginTransaction();
			Person loadedParent = (Person) currentSession().get(Person.class, parent.getId());
			assertFalse(loadedParent.getChildren().isEmpty());
			currentSession().getTransaction().commit();
		} catch (RuntimeException e) {
			currentSession().getTransaction().rollback();
			throw e;
		}
	}

	private void addNewChild(Person parent) {
		Person child = new Person("child");
		try {
			currentSession().beginTransaction();
			currentSession().save(child);
			Person loadedParent = (Person) currentSession().get(Person.class, parent.getId());
			loadedParent.addChild(loadedParent);
			currentSession().getTransaction().commit();
			assertNotNull(child.getId());
		} catch (RuntimeException e) {
			currentSession().getTransaction().rollback();
			throw e;
		}
	}

	private void loadParentAndChildrenIntoCache(Person parent) {
		try {
			currentSession().beginTransaction();
			Person p = (Person) currentSession().get(Person.class, parent.getId());
			assertTrue(p.getChildren().isEmpty());
			currentSession().getTransaction().commit();
		} catch (RuntimeException e) {
			currentSession().getTransaction().rollback();
			throw e;
		}
	}

	private void createParent(Person parent) {
		try {
			currentSession().beginTransaction();
			currentSession().save(parent);
			currentSession().getTransaction().commit();
			assertNotNull(parent.getId());
		} catch (RuntimeException e) {
			currentSession().getTransaction().rollback();
			throw e;
		}
	}


}
