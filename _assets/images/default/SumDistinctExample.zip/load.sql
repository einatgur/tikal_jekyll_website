DROP TABLE IF EXISTS `testProduct`;
CREATE TABLE `testProduct` (
  `ProductCategory` varchar(255) NOT NULL,
  `ProductGroup` varchar(255) NOT NULL,
  `Product` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

DROP TABLE IF EXISTS `testType`;
CREATE TABLE `testType` (
  `TypeLetter` varchar(255) NOT NULL,
  `TypeNumber` varchar(255) NOT NULL,
  `TypeCode` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

DROP TABLE IF EXISTS `testContract`;
CREATE TABLE `testContract` (
  `Contract` varchar(255) NOT NULL,
  `Profit` float NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

DROP TABLE IF EXISTS `testContractProductType`;
CREATE TABLE `testContractProductType` (
  `Contract` varchar(255) NOT NULL,
  `Product` varchar(255) NOT NULL,
  `TypeCode` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

DROP VIEW IF EXISTS `testJoinTable`;
CREATE VIEW `testJoinTable` AS
SELECT tc.Contract, tp.ProductCategory, tp.ProductGroup, tcpt.Product, tt.TypeLetter, tt.TypeNumber, tt.typeCode, tc.Profit 
FROM testContract tc, testContractProductType tcpt, testProduct tp, testType tt
WHERE tc.Contract=tcpt.Contract AND tcpt.Product=tp.Product AND tcpt.TypeCode=tt.TypeCode; 

insert into testProduct VALUES ('Media','Stream','VOD');
insert into testProduct VALUES ('Media','Stream','TV');
insert into testProduct VALUES ('Disks','DVD','rental');

insert into testType VALUES ('A','2','A2');
insert into testType VALUES ('A','1','A1');
insert into testType VALUES ('B','1','B1');

insert into testContract VALUES ('5000',1000);
insert into testContract VALUES ('5001',2000);
insert into testContract VALUES ('5002',1000);

insert into testContractProductType VALUES ('5000','VOD','A1');
insert into testContractProductType VALUES ('5000','TV','A1');
insert into testContractProductType VALUES ('5001','VOD','A1');
insert into testContractProductType VALUES ('5001','rental','B1');
insert into testContractProductType VALUES ('5002','TV','A1');

SHOW WARNINGS;
