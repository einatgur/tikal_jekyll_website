package com.tikal.envers.model;

import java.io.Serializable;
import java.util.Date;

import org.jboss.envers.Versioned;
import org.jboss.envers.Unversioned;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.GeneratedValue;

/**
 * User: Gad Mehditache
 * Date: Nov 4, 2008
 * Time: 2:08:36 PM
 */
@Entity
@Versioned
public class Car implements Serializable {

    @Id
	@GeneratedValue
    private Long id;

    private String manufacturer;


    public Car() {}

    public Car(String manufacturer) {
        this.manufacturer = manufacturer;
    }


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    
}
