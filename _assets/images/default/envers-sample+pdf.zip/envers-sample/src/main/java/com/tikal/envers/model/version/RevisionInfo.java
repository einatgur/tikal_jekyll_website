package com.tikal.envers.model.version;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.jboss.envers.RevisionEntity;
import org.jboss.envers.RevisionNumber;
import org.jboss.envers.RevisionTimestamp;

import com.tikal.envers.cfg.RevisionInfoListener;

@Entity
@RevisionEntity(RevisionInfoListener.class)
@Table(name = "_revisions_info_")
public class RevisionInfo implements Serializable {
	@Id
	@GeneratedValue
	@RevisionNumber
	private Long id;
	@RevisionTimestamp
	private Long revisionTimestamp;

    private String userName;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getRevisionTimestamp() {
		return revisionTimestamp;
	}

	public void setRevisionTimestamp(Long revisionTimestamp) {
		this.revisionTimestamp = revisionTimestamp;
	}

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }



}
