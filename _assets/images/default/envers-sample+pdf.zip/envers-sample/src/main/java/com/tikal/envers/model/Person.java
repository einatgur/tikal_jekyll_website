package com.tikal.envers.model;

import org.jboss.envers.Versioned;
import org.jboss.envers.VersionsJoinTable;

import javax.persistence.*;

import java.util.Set;
import java.util.HashSet;
import java.io.Serializable;

/**
 * User: Gad Mehditache
 * Date: Nov 4, 2008
 * Time: 2:06:54 PM
 */
@Entity
@Versioned
public class Person implements Serializable {
    @Id
	@GeneratedValue
    private Long id;
    private String name;

    @OneToMany
    @JoinColumn(name = "person_id")
    @VersionsJoinTable(name = "_rev_join_person_car_")
    private Set<Car> cars = new HashSet<Car>();

    public Person() {}

    public Person(String name) {
        this.name = name;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Set<Car> getCars() {
        return cars;
    }

    public void setCars(Set<Car> cars) {
        this.cars = cars;
    }
}
