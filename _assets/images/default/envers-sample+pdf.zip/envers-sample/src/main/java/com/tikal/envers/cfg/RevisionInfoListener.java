package com.tikal.envers.cfg;

import com.tikal.envers.model.version.RevisionInfo;
import org.jboss.envers.RevisionListener;

public class RevisionInfoListener implements RevisionListener {
    @Override
	public void newRevision(Object revEntity) {               
        ((RevisionInfo)revEntity).setUserName("system");
	}
}