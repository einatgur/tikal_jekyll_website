package com.tikal.envers;

import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.Before;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.ImprovedNamingStrategy;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.jboss.envers.VersionsReader;
import org.jboss.envers.VersionsReaderFactory;

import java.beans.PropertyVetoException;

import com.tikal.envers.model.Person;
import com.tikal.envers.model.Car;

import junit.framework.Assert;
import org.junit.AfterClass;

/**
 * User: Gad Mehditache
 * Date: Nov 4, 2008
 * Time: 2:03:15 PM
 */


public class BasicEnversTest {

    private static SessionFactory sf;

    @BeforeClass
    public static void init() throws PropertyVetoException {

        Configuration configuration = new AnnotationConfiguration().configure("/hibernate.cfg.xml");
        configuration.setNamingStrategy(ImprovedNamingStrategy.INSTANCE);
        sf = configuration.buildSessionFactory();

    }

    @AfterClass
    public static void release()   {

        if (sf!=null) {
            sf.close();
        }
        
    }

    @Before
    public void insert() {
        beginTx();

        Person person = new Person("John");
        Car car = new Car("Susita");
        getCurrentSession().save(car);
        person.getCars().add(car);
        getCurrentSession().save(person);

        commit();

        beginTx();

        car.setManufacturer("Mazda");
        getCurrentSession().update(car);

        commit();


    }

    @Test
    public void fetch() {
        beginTx();

        Person person = getVersionsReader().find(Person.class,1l,1l);
        Car car = person.getCars().iterator().next(); 

        commit();

        Assert.assertEquals("Susita", car.getManufacturer());


    }





    protected void beginTx() {
        sf.getCurrentSession().getTransaction().begin();
    }

    protected void commit() {
        sf.getCurrentSession().getTransaction().commit();
    }

    protected Session getCurrentSession()  {
        return sf.getCurrentSession();
    }


    protected VersionsReader getVersionsReader() {
        return VersionsReaderFactory.get(sf.getCurrentSession());
    }
}
