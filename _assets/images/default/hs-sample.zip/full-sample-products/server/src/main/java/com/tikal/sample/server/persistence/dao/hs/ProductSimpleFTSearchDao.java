package com.tikal.sample.server.persistence.dao.hs;

import java.util.List;

import javax.annotation.Resource;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.queryParser.ParseException;
import org.apache.lucene.queryParser.QueryParser;
import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.ScrollableResults;
import org.hibernate.SessionFactory;
import org.hibernate.search.FullTextQuery;
import org.hibernate.search.FullTextSession;
import org.hibernate.search.Search;
import org.springframework.stereotype.Repository;

import com.tikal.sample.domain.model.Product;
import com.tikal.sample.server.persistence.dao.ProductFullTextDao;
import com.tikal.sample.server.service.ResultsPage;


@Repository("productSimpleFTSearchDao")
public class ProductSimpleFTSearchDao implements ProductFullTextDao{
	private final static org.slf4j.Logger log = org.slf4j.LoggerFactory
			.getLogger(ProductSimpleFTSearchDao.class);

	@Resource
	private SessionFactory sessionFactory;

	protected FullTextSession fullTextSession() {
		return Search.getFullTextSession(sessionFactory.getCurrentSession());
	}


	@Override
	public ResultsPage<Product> search(String searchQuery, short pageSize, int pageNo) {
		//1. Build a Lucene query
		org.apache.lucene.search.Query luceneQuery = buildLuceneQuery(searchQuery);

		//2. Build a FullTextQuery
		FullTextQuery fullTextQuery = buildFullTextQuery(pageSize, pageNo, luceneQuery);

		//3. Execute the FullTextQuery and build a results page
		ResultsPage<Product> productsPage = executeQuery(fullTextQuery);

		return productsPage;
	}




	protected org.apache.lucene.search.Query buildLuceneQuery(String searchQuery) {
		try {
			Analyzer analyzer = fullTextSession().getSearchFactory().getAnalyzer(Product.class);
			QueryParser parser = new QueryParser("title",analyzer);
			org.apache.lucene.search.Query luceneQuery = parser.parse(searchQuery);
			log.debug("luceneQuery--->   "+luceneQuery);
			return luceneQuery;
		} catch (ParseException e) {
			throw new RuntimeException("parsing error:"+e.getMessage(), e);
		}
	}

	protected FullTextQuery buildFullTextQuery(short pageSize,int pageNo,
			org.apache.lucene.search.Query luceneQuery) {

		FullTextQuery query = fullTextSession().createFullTextQuery(luceneQuery,Product.class);

		Criteria fetchingStrategy = fullTextSession().createCriteria(Product.class)
			.setFetchMode("categories", FetchMode.JOIN)
			.setFetchMode("actors", FetchMode.JOIN);


		query.setFirstResult( (pageNo-1)*pageSize).setMaxResults(pageSize)
					.setCriteriaQuery(fetchingStrategy);

		return query;
	}

	@SuppressWarnings("unchecked")
	protected ResultsPage<Product> executeQuery(FullTextQuery fullTextQuery) {
		List<Product> results = fullTextQuery.list();
		int totalResults = fullTextQuery.getResultSize();
		ResultsPage<Product> productsPage = new ResultsPageImpl<Product>(totalResults,results);
		return productsPage;
	}







	@Override
	public void indexAll() {
		int batchSize = 100;
		ScrollableResults scroll = fullTextSession()
				.createCriteria(Product.class).setFetchMode("categories", FetchMode.JOIN).setFetchMode("actors", FetchMode.JOIN)
				.setFetchSize(batchSize).scroll();

		scroll.beforeFirst();
		for (int batch = 0; scroll.next(); batch++) {
			fullTextSession().index(scroll.get(0));
			if (batch % batchSize == 0) {
				fullTextSession().flushToIndexes();
				fullTextSession().clear();
			}
		}
		fullTextSession().getSearchFactory().optimize();

	}

	@Override
	public void purgeAll() {
		fullTextSession().purgeAll(Product.class);
		fullTextSession().getSearchFactory().optimize();
	}



}
