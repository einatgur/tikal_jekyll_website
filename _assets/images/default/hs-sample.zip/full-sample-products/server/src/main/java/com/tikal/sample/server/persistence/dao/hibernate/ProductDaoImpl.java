package com.tikal.sample.server.persistence.dao.hibernate;

import java.util.List;

import javax.annotation.Resource;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Repository;

import com.tikal.sample.domain.model.Product;
import com.tikal.sample.server.persistence.dao.ProductDao;
import com.tikal.sample.server.persistence.dao.hs.ResultsPageImpl;
import com.tikal.sample.server.service.ResultsPage;

@Repository("productDao")
public class ProductDaoImpl implements ProductDao {

	@Resource
	private SessionFactory sessionFactory;

	private Session currentSession() {
		return sessionFactory.getCurrentSession();
	}

	@Override
	public Product create(Product product) {
		currentSession().save(product);
		return product;
	}

	@Override
	public Product update(Product product) {
		currentSession().update(product);
		return product;
	}

	@Override
	public Product findById(long id) {
		return (Product) currentSession().get(Product.class, id);
	}

	@SuppressWarnings("unchecked")
	@Override
	public ResultsPage<Product>  search(String searchQuery,short pageSize,int pageNo){
		String hql = "select p from Product p " +
					" left join fetch p.actors a " +
					" left join fetch p.categories c" +
					" where p.title like :searchQuery " +
					" or p.description like :searchQuery "+
					" or c.name like :searchQuery "+
					" or a.name like :searchQuery ";

		String hqlCount = "select count(p) from Product p " +
						" left join p.actors a " +
						" left join p.categories c" +
						" where p.title like :searchQuery " +
						" or p.description like :searchQuery "+
						" or c.name like :searchQuery "+
						" or a.name like :searchQuery ";

		long totalResults= (Long) currentSession().createQuery(hqlCount).setString("searchQuery", searchQuery).uniqueResult();

		List results = currentSession().createQuery(hql).setString("searchQuery", searchQuery).setFirstResult( (pageNo - 1) * pageSize )
		.setMaxResults( pageSize ).list();

		return new ResultsPageImpl<Product>((int)totalResults,results);
	}

}
