package com.tikal.sample.server.persistence.dao.hs;

import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.queryParser.MultiFieldQueryParser;
import org.apache.lucene.queryParser.ParseException;
import org.apache.lucene.queryParser.QueryParser;
import org.springframework.stereotype.Repository;

import com.tikal.sample.domain.model.Product;
import com.tikal.sample.server.service.ResultsPage;

@Repository("productAdvancedFTSearchDao")
public class ProductAdvancedFTSearchDao extends ProductSimpleFTSearchDao{
	private final static org.slf4j.Logger log = org.slf4j.LoggerFactory
			.getLogger(ProductAdvancedFTSearchDao.class);



	@Override
	public ResultsPage<Product> search(String searchQuery, short pageSize, int pageNo) {
		ResultsPage<Product> productsPage = phraseSearch(searchQuery, pageSize, pageNo);
		if(hasEnoughResults(productsPage))
			return productsPage;

		productsPage = proximityPhraseSearch(searchQuery, pageSize, pageNo);
		if(hasEnoughResults(productsPage))
			return productsPage;

		productsPage = exactWordsSearch(searchQuery, pageSize, pageNo);
		if(hasEnoughResults(productsPage))
			return productsPage;

		productsPage = fuzzySearch(searchQuery, pageSize, pageNo);
		if(hasEnoughResults(productsPage))
			return productsPage;

		productsPage = prefixSearch(searchQuery, pageSize, pageNo);

		return productsPage;
	}

	private ResultsPage<Product> prefixSearch(String searchQuery,short pageSize, int pageNo) {
		log.debug("Trying prefix search");

		String prefixSearch = searchQuery.trim()+"*";
		ResultsPage<Product> productsPage = super.search(prefixSearch,pageSize, pageNo);
		return productsPage;
	}

	private boolean hasEnoughResults(ResultsPage<Product> productsPage) {
		return !(productsPage.getResults().isEmpty());
	}

	private ResultsPage<Product> phraseSearch(String searchQuery, short pageSize, int pageNo){
		log.debug("Trying phrase search");

		String phrase = "\""+searchQuery+"\"";
		ResultsPage<Product> productsPage = super.search(phrase,pageSize, pageNo);
		return productsPage;
	}

	private ResultsPage<Product> proximityPhraseSearch(String searchQuery, short pageSize, int pageNo){
		log.debug("Trying proximity-phrase search");

		String proximityPhrase = "\""+searchQuery+"\""+"~3";
		ResultsPage<Product> productsPage = super.search(proximityPhrase,pageSize, pageNo);
		return productsPage;
	}

	private ResultsPage<Product> exactWordsSearch(String searchQuery, short pageSize, int pageNo){
		log.debug("Trying exact-words search");
		ResultsPage<Product> productsPage = super.search(searchQuery,pageSize, pageNo);
		return productsPage;
	}

	private ResultsPage<Product> fuzzySearch(String searchQuery, short pageSize, int pageNo){
		String minimumSimilarity = "~0.7";
		log.debug("Trying fuzzy search ");

		StringTokenizer st = new StringTokenizer(searchQuery, " ");
		StringBuilder stringBuilder = new StringBuilder();
		while (st.hasMoreTokens())
			stringBuilder.append(st.nextToken()+minimumSimilarity+" ");
		ResultsPage<Product> productsPage = super.search(stringBuilder.toString(),pageSize, pageNo);
		return productsPage;
	}




	@Override
	protected org.apache.lucene.search.Query buildLuceneQuery(String searchQuery) {
		Map<String, Float> boostPerField = new HashMap<String, Float>(4);
        boostPerField.put("title", (float) 4);
        boostPerField.put("description", (float) 2);
        boostPerField.put("actors.name", (float) 3);
        boostPerField.put("categories.name", (float) .5);

		try {
			Analyzer analyzer = fullTextSession().getSearchFactory().getAnalyzer(Product.class);
			QueryParser parser = new MultiFieldQueryParser(boostPerField.keySet().toArray(new String[]{}), analyzer, boostPerField);
			org.apache.lucene.search.Query luceneQuery = parser.parse(searchQuery);
			log.debug("luceneQuery--->   "+luceneQuery);
			return luceneQuery;
		} catch (ParseException e) {
			throw new RuntimeException("parsing error:"+e.getMessage(), e);
		}
	}


}
