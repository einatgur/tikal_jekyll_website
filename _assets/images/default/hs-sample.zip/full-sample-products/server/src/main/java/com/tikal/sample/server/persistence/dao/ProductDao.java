package com.tikal.sample.server.persistence.dao;

import com.tikal.sample.domain.model.Product;
import com.tikal.sample.server.service.ResultsPage;

public interface ProductDao {
	Product create(Product product);

	Product update(Product product);

	Product findById(long id);

	ResultsPage<Product>  search(String searchQuery,short pageSize,int pageNo);
}
