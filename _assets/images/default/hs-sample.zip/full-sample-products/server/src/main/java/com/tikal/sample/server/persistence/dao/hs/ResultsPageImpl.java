package com.tikal.sample.server.persistence.dao.hs;

import java.util.List;

import com.tikal.sample.server.service.ResultsPage;

public class ResultsPageImpl<T> implements ResultsPage<T>{
	private int approximateTotalResults;
	private List<T> results;


	public ResultsPageImpl(int approximateTotalResults, List<T> results) {
		this.approximateTotalResults = approximateTotalResults;
		this.results = results;
	}

	@Override
	public int getApproximateTotalResults() {
		return approximateTotalResults;
	}

	@Override
	public List<T> getResults() {
		return results;
	}

}
