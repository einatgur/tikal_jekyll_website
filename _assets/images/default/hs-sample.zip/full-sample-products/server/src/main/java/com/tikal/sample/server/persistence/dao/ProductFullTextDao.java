package com.tikal.sample.server.persistence.dao;

import com.tikal.sample.domain.model.Product;
import com.tikal.sample.server.service.ResultsPage;

public interface ProductFullTextDao {

	ResultsPage<Product> search(String searchQuery, short pageSize, int pageNo) ;
	void indexAll();
	void purgeAll();

}
