package com.tikal.sample.server.service.impl;

import java.util.LinkedList;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;

import com.tikal.sample.domain.model.Product;
import com.tikal.sample.server.persistence.dao.ProductDao;
import com.tikal.sample.server.persistence.dao.ProductFullTextDao;
import com.tikal.sample.server.persistence.dao.hs.ResultsPageImpl;
import com.tikal.sample.server.service.ProductService;
import com.tikal.sample.server.service.ResultsPage;


@Service("productService")
public class ProductServiceImpl implements ProductService{
	private final static org.slf4j.Logger log = org.slf4j.LoggerFactory
			.getLogger(ProductServiceImpl.class);
	@Resource
	private ProductDao productDao;

	@Resource
	private TransactionTemplate transactionTemplate;

	@Resource
	private ProductFullTextDao productSimpleFTSearchDao;

	@Resource
	private ProductFullTextDao productAdvancedFTSearchDao;


	@Override
	public ResultsPage<Product> search(String searchQuery,short pageSize,int pageNo) {
		if(searchQuery.endsWith(" *"))
			searchQuery = searchQuery.replaceAll(" \\*", "");


		if(searchQuery==null || searchQuery.isEmpty())
			return new ResultsPageImpl<Product>(0,new LinkedList<Product>());

		ResultsPage<Product>  productsPage;
		log.debug("************************************************************************************************************");
		if(isLuceneQuery(searchQuery)){
			log.debug("Applying simple search for "+searchQuery);
			productsPage =  productSimpleFTSearchDao.search(searchQuery,pageSize,pageNo);
		}else{
			log.debug("Applying advananced search for "+searchQuery);
			productsPage = productAdvancedFTSearchDao.search(searchQuery,pageSize,pageNo);
		}

		if (log.isDebugEnabled())
			log.debug(summary(productsPage, searchQuery,pageSize,pageNo));
		return productsPage;

	}

	private String summary(ResultsPage<Product> productsPage,String searchQuery,short pageSize,int pageNo){
		if(productsPage.getResults().isEmpty())
			return ("No results found");
		int first = (pageNo-1)*pageSize+1;
		int last = Math.min(productsPage.getResults().size(),pageNo*pageSize);
		return "Results "+first+" - "+last+
					" out of - "+productsPage.getApproximateTotalResults()+
					" for "+searchQuery;

	}




	@Override
	public ResultsPage<Product> simpleSearch(String searchQuery,short pageSize,int pageNo) {
		log.debug("Applying simple search for "+searchQuery);
		if(searchQuery==null || searchQuery.isEmpty())
			return new ResultsPageImpl<Product>(0,new LinkedList<Product>());
		return productSimpleFTSearchDao.search(searchQuery,pageSize,pageNo);
	}




	private boolean isLuceneQuery(String searchQuery){
		return (searchQuery.startsWith("\"") ||
				searchQuery.contains("*") ||
				searchQuery.contains(":") ||
				searchQuery.contains("~"));
	}







////////////////////// Some more methods on the Service layer ////////////////////////

	@PostConstruct
	public void initIndex() {
		//This is only a demo. In practice we never do it here
		transactionTemplate.execute(new TransactionCallbackWithoutResult() {
			protected void doInTransactionWithoutResult(TransactionStatus status) {
				purgeAll();
				indexAll();
			}
		});
	}

	@Override
	public Product createProduct(Product product) {
		return productDao.create(product);
	}

	@Override
	public Product updateProduct(Product product) {
		return productDao.update(product);
	}

	@Override
	public Product findProductById(long id) {
		return productDao.findById(id);
	}

	private void indexAll() {
		productSimpleFTSearchDao.indexAll();
	}

	private void purgeAll() {
		productSimpleFTSearchDao.purgeAll();
	}



	@Override
	public ResultsPage<Product>  searchFromDB(String searchQuery,short pageSize,int pageNo) {
		return productDao.search(searchQuery,pageSize,pageNo);
	}


}
