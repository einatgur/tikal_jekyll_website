package com.tikal.sample.hibernatesearch;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.apache.lucene.index.Term;
import org.apache.lucene.search.TermQuery;
import org.hibernate.SessionFactory;
import org.hibernate.search.FullTextSession;
import org.hibernate.search.Search;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;

import com.tikal.sample.AbstractTransactionalSpringContextTest;
import com.tikal.sample.domain.model.Product;

@ContextConfiguration(locations = { "classpath*:/spring/**/applicationContext*.xml" })
public class TestTermQuery extends AbstractTransactionalSpringContextTest {
	@Autowired
	private SessionFactory sessionFactory;

	private static final String FIELD_NAME = "description";
	String[] descs = new String[] { "he hits the road as a traveling salesman",
			"he's not a computer salesman",
			"a traveling salesman touting the wave of the future",
			"transforms into an aggressive, high-risk salesman",
			"a once-successful salesman" };

	@SuppressWarnings("unchecked")
	@Test
	public void testTermQuery() throws Exception {
		buildIndex();
		String userInput = "salesman";
		startTransaction();
		Term term = new Term(FIELD_NAME, userInput);
		TermQuery query = new TermQuery(term);
		System.out.println(query.toString());
		org.hibernate.search.FullTextQuery hibQuery = ftSession().createFullTextQuery(query, Product.class);
		List<Product> results = hibQuery.list();
		assertEquals("incorrect hit count", 5, results.size());
		assertEquals("he's not a computer salesman", results.get(0).getDescription());
		for (Product product : results) {
			System.out.println(product.getDescription());
		}
		for (Object element : ftSession().createQuery(
				"from " + Product.class.getName()).list())
			ftSession().delete(element);
		commit();
	}

	private void buildIndex() {
		startTransaction();
		for (int x = 0; x < descs.length; x++) {
			Product dvd = new Product();
			dvd.setDescription(descs[x]);
			ftSession().save(dvd);
		}
		commit();
	}



	private FullTextSession ftSession() {
		return Search.getFullTextSession(sessionFactory.getCurrentSession());
	}

}
