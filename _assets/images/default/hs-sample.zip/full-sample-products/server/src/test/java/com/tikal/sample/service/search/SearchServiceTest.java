package com.tikal.sample.service.search;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import javax.annotation.Resource;

import org.junit.Before;
import org.junit.Test;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;

import com.tikal.sample.domain.model.Product;
import com.tikal.sample.server.service.ProductService;

@ContextConfiguration(
		locations=
		{"classpath*:/spring/**/applicationContext*.xml"})
public class SearchServiceTest extends AbstractJUnit4SpringContextTests {

	private static boolean  initialized;

	@Resource
	private ProductService productService;

	@Before
	public void setup(){
		if(initialized)
			return ;
		createProducts();
		initialized=true;

		//done in the setup of the servivce
//		productService.purgeAll();
//		productService.indexAll();

	}

	@Test
	public void searchDBService(){
		assertEquals(1, productService.searchFromDB("%Fair%", (short)10, 1).getResults().size());
	}

	@Test
	public void searchService(){
		assertEquals(1, productService.simpleSearch("A dvd about persisting objects with ybernate in Java", (short)10, 1).getResults().size());
	}

	private void createProducts() {
		Product product8 = new Product();
		product8.setASIN("1-932394-88-5");
		product8.setTitle("Java Persistence with Hibernate");
		product8.setPrice(19.98d);
		product8.setImageURL("Following the succuess of the book, now we publish a dvd with the couse sessions and training.");
		assertTrue(productService.createProduct(product8).getId()!=null);


		Product product = new Product();
		product.setASIN("630522577X");
		product.setTitle("My Fair Lady");
		product.setPrice(19.98d);
		product.setImageURL("http://images.amazon.com/images/P/630522577X.01.MZZZZZZZ.jpg");
		product.setDescription("Hollywood''s legendary \"woman''s director,\" George Cukor (The Women, The Philadelphia Story)" +
				", transformed Audrey Hepburn into street-urchin-turned-proper-lady Eliza Doolittle in this film version of " +
				"the Lerner and Loewe musical. Based on George Bernard Shaw''s play Pygmalion, My Fair Lady stars Rex Harrison " +
				"as linguist Henry Higgins (Harrison also played the role, opposite Julie Andrews, on stage), who draws Eliza " +
				"into a social experiment that works almost too well. The letterbox edition of this film on video certainly " +
				"pays tribute to the pageantry of Cukor''s set, but it also underscores a certain visual stiffness that can " +
				"slow viewer enthusiasm just a tad. But it''s really star wattage that keeps this film exciting, that and " +
				"such great songs as \"On the Street Where You Live\" and \"I Could Have Danced All Night.\" Actor Jeremy " +
				"Brett, who gained a huge following later in life portraying Sherlock Holmes, is quite electric as Eliza''s determined suitor.");
		assertTrue(productService.createProduct(product).getId()!=null);


		Product product2 = new Product();
		product2.setASIN("B00003CXCD");
		product2.setTitle("Roman Holiday");
		product2.setPrice(12.98d);
		product2.setImageURL("http://images.amazon.com/images/P/B00003CXCD.01.MZZZZZZZ.jpg");
		product2.setDescription("Maybe it doesn''t quite live up to its sterling reputation, and maybe the leading man and " +
				"director were slightly miscast. But who cares? Roman Holiday is the film that brought Audrey Hepburn to " +
				"prominence, and the world movie audience went weak at the knees. The endlessly charming Hepburn had her " +
				"first starring role in this sweet romance, playing a European princess on an official tour through Rome. " +
				"Frustrated by her lack of connection to the real world, she slips away from her protective handlers and " +
				"goes on a spree, aided by a tough-guy news reporter (Gregory Peck). Director William Wyler, more at home " +
				"with such heavy-going, Oscar-winning classics as The Best Years of Our Lives and Ben- Hur, doesn''t always " +
				"keep the champagne bubbles afloat, and the Peck role would have fit Cary Grant like a silk glove. But the film " +
				"is great fun, the location shooting is irresistible, and Hepburn embodies an image of chic style that would rule" +
				" for the rest of the fifties. No coincidence: she won an Oscar, and so did veteran costume designer Edith Head. ");
		assertTrue(productService.createProduct(product2).getId()!=null);


		Product product3 = new Product();
		product3.setASIN("B00000IQW5");
		product3.setTitle("Always");
		product3.setPrice(19.98d);
		product3.setImageURL("http://images.amazon.com/images/P/B00000IQW5.01.MZZZZZZZ.jpg");
		product3.setDescription("Considered by many to represent a low point in Steven Spielberg''s  career, " +
				" 1990''s Always did suggest something of a temporary drift in the  director''s sensibility. " +
				"A remake of the  classic Spencer Tracy film A Guy Named Joe, Always stars  Richard Dreyfuss " +
				"as a Forest Service pilot who takes great risks with his own  life to douse wildfires from a" +
				" plane. After promising his frightened fianc&eacute;e  (Holly Hunter) to keep his feet on the" +
				" ground and go into teaching,  Dreyfuss''s character is killed during one last flight. But his " +
				"spirit wanders  restlessly, hopelessly attached to and possessive of Hunter, who can''t see or  " +
				"hear him. Then the real conflict begins: a trainee pilot (Brad Johnson), a  likable doofus, begins" +
				" wooing a not-unappreciative Hunter");
		assertTrue(productService.createProduct(product3).getId()!=null);


		//('14', 'B000B8QG0O', 'Toy Story 2 ', 29.99, 'http://images.amazon.com/images/P/B000B8QG0O.01.MZZZZZZZ.jpg', 'John Lasseter and his gang of high-tech creators at Pixar create another entertainment for the ages. Like the few great movie sequels, Toy Story&nbsp;2 comments on why the first one was so wonderful while finding a fresh angle worthy of a new film. The craze of toy collecting becomes the focus here, as we find out Woody (voiced by Tom Hanks) is not only a beloved toy to Andy but also a rare doll from a popular ''60s children''s show. When a greedy collector takes Woody, Buzz Lightyear (Tim Allen) launches a rescue mission with Andy''s other toys. To say more would be a crime because this is one of the most creative and smile-inducing films since, well, the first Toy Story.   Although the toys look the same as in the 1994 feature, Pixar shows how much technology has advanced: the human characters look more human, backgrounds are superior, and two action sequences that book-end the film are dazzling. And it''s a hoot for kids and adults. The film is packed with spoofs, easily accessible in-jokes, and inspired voice casting (with newcomer Joan Cusack especially a delight as Cowgirl Jessie). But as the Pixar canon of films illustrates, the filmmakers are storytellers first. Woody''s heart-tugging predicament can easily be translated into the eternal debate of living a good life versus living  forever. Toy Story&nbsp;2 also achieved something in the U.S. two other outstanding 1999 animated features (The Iron Giant, Princess Mononoke) could not: it became a huge box-office hit. ');

		Product product4 = new Product();
		product4.setASIN("B000B8QG0O");
		product4.setTitle("Toy Story 2");
		product4.setPrice(29.99f);
		product4.setImageURL("http://images.amazon.com/images/P/B000B8QG0O.01.MZZZZZZZ.jpg");
		product4.setDescription("John Lasseter and his gang of high-tech creators " +
				"at Pixar create another entertainment for the ages. Like the few great movie " +
				"sequels, Toy Story&nbsp;2 comments on why the first one was so wonderful while " +
				"finding a fresh angle worthy of a new film. The craze of toy collecting becomes the " +
				"focus here, as we find out Woody (voiced by Tom Hanks) is not only a beloved toy to " +
				"Andy but also a rare doll from a popular ''60s children''s show. When a greedy collector " +
				"takes Woody, Buzz Lightyear (Tim Allen) launches a rescue mission with Andy''s other toys." +
				" To say more would be a crime because this is one of the most creative " +
				"and smile-inducing films since, well, the first Toy Story.   Although the toys " +
				"look the same as in the 1994 feature, Pixar shows how much technology has advanced:" +
				" the human characters look more human, backgrounds are superior, and two action " +
				"sequences that book-end the film are dazzling. And it''s a hoot for kids and adults." +
				" The film is packed with spoofs, easily accessible in-jokes, and inspired voice casting" +
				" (with newcomer Joan Cusack especially a delight as Cowgirl Jessie). But as the Pixar " +
				"canon of films illustrates, the filmmakers are storytellers first. Woody''s heart-tugging" +
				" predicament can easily be translated into the eternal debate of living a good life versus " +
				"living  forever. Toy Story&nbsp;2 also achieved something in the U.S. two other outstanding " +
				"1999 animated features (The Iron Giant, Princess Mononoke) could not: it became a huge" +
				" box-office hit. ");
		assertTrue(productService.createProduct(product4).getId()!=null);
	}

}
