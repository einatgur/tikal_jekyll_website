package com.tikal.sample.service.search;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import org.junit.Ignore;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.tikal.sample.domain.model.Actor;
import com.tikal.sample.domain.model.Category;
import com.tikal.sample.domain.model.Product;
import com.tikal.sample.server.service.ProductService;
import com.tikal.sample.server.service.ResultsPage;
@Ignore
public class SearchDemo extends JFrame {



    private DefaultTableModel model;

    private TableModelListener modelListener;

    private ProductService productService;


//    private static String[] productFields = {"title",
//            "description",
//            "actors.name",
//            "categories.name"};

    private static String[] headers = {"id",
            "asin",
            "title",
            "actors",
            "categories","descitopn"};



    SearchDemo() {
    	super("Hibernate Search Demo");
    	ApplicationContext applicationContext = new ClassPathXmlApplicationContext("spring/applicationContext.xml");
    	productService = (ProductService) applicationContext.getBean("productService");

//    	productService.purgeAll();
//    	productService.indexAll();
        initWidgets();
    }

    private void initWidgets() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setDefaultLookAndFeelDecorated(true);

        BorderLayout borderLayout = new BorderLayout();
        getContentPane().setLayout(borderLayout);

        // the main table
        model = new DefaultTableModel(headers, 0) {
            public boolean isCellEditable(int row, int column) {
                // at the moment only allows the editing of the title
                return column == 2;
            }
        };
        modelListener = new TableModelListener() {
            public void tableChanged(TableModelEvent e) {
                int row = e.getFirstRow();
                int column = e.getColumn();
                TableModel model = (TableModel) e.getSource();
                Object data = model.getValueAt(row, column);
                updateTitle((Long) model.getValueAt(row, 0), (String) data);
            }
        };
        model.addTableModelListener(modelListener);
        final JTable table = new JTable(model);

        table.setFont(new Font("Courier New", Font.PLAIN, 14));
        getContentPane().add(new JScrollPane(table), BorderLayout.CENTER);

        // build  the controls
        JPanel controlPanel = new JPanel();
        controlPanel.setLayout(new FlowLayout());

        final JLabel resultsSummary = new JLabel();
        resultsSummary.setForeground(Color.red);
        controlPanel.add(resultsSummary);

        final JTextField searchField = new JTextField(30);
        controlPanel.add(searchField);

        JButton searchButton = new JButton("Search");
        searchButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {


            	ResultsPage<Product> productsPage;

                try {
                	long start = System.currentTimeMillis();
                	productsPage = search(searchField.getText());
                	long time = (System.currentTimeMillis()-start)/10;
                	float secTime = time/(100f);
                	resultsSummary.setText(productsPage.getResults().size()+" out of "+productsPage.getApproximateTotalResults()+" ("+secTime+" sec)");
                } catch (RuntimeException re) {
                    JOptionPane.showMessageDialog(null, re.getMessage(), "alert", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                DefaultTableModel model = (DefaultTableModel) table.getModel();
                model.removeTableModelListener(modelListener);
                model.setRowCount(0);
                for (int i = 0; i < productsPage.getResults().size(); i++) {
                    Object[] data = new Object[headers.length];
                    Product p = productsPage.getResults().get(i);
                    data[0] = p.getId();
                    data[1] = p.getASIN();
                    data[2] = p.getTitle();
                    String actors = "";
                    for (Actor actor : p.getActors()) {
                        actors = actors + actor.getName() + ", ";
                    }
                    data[3] = actors.length() == 0 ? actors : actors.substring(0, actors.length() - 2);
                    String categories = "";
                    for (Category category : p.getCategories()) {
                        categories = categories + category.getName() + ", ";
                    }
                    data[4] = categories.length() == 0 ? categories : categories.substring(0, categories.length() - 2);
                    data[5] = p.getDescription();
                    model.insertRow(i, data);
                }
                model.addTableModelListener(modelListener);
            }
        });
        controlPanel.add(searchButton);

//        JButton indexButton = new JButton("Index");
//        indexButton.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                productService.indexAll();
//            }
//        });
//        controlPanel.add(indexButton);

//        JButton purgeButton = new JButton("Purge");
//        purgeButton.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//            	productService.purgeAll();
//            }
//        });
//        controlPanel.add(purgeButton);

        getContentPane().add(controlPanel, BorderLayout.NORTH);
        getRootPane().setDefaultButton(searchButton);


        setSize(800, 200);
        setVisible(true);
    }


    private ResultsPage<Product> search(String searchQuery)  {
    	return productService.simpleSearch(searchQuery,(short)10,1);
    }



    private void updateTitle(long id, String title) {
            Product product = productService.findProductById(id);
            if (product != null) {
                product.setTitle(title);
                productService.updateProduct(product);
            }
    }




    public static void main(final String[] args) {
        javax.swing.SwingUtilities.invokeLater(
                new Runnable() {
                    public void run() {
                        new SearchDemo();
                    }
                });

    }
}
