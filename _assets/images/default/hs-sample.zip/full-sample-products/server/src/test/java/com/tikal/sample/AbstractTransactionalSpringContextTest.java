package com.tikal.sample;

import java.util.EmptyStackException;
import java.util.Stack;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.test.context.transaction.TransactionalTestExecutionListener;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

/**
 * base transactional abstract class for Spring tests,extends
 * <code>AbstractSpringContextTest</code> and adds transactional support
 *
 *
 */
@TestExecutionListeners( { TransactionalTestExecutionListener.class })
@TransactionConfiguration(transactionManager = "txManager")
@ContextConfiguration(locations = { "classpath*:/spring/**/applicationContext*.xml" })
public abstract class AbstractTransactionalSpringContextTest extends
		AbstractJUnit4SpringContextTests {

	@javax.annotation.Resource(name = "sessionFactory")
	private SessionFactory sessionFactory;

	@Autowired
	private PlatformTransactionManager platformTransactionManager;

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	/**
	 * convenient method to get the application context,it is a protected member
	 * in AbstractJUnit4SpringContextTests.
	 *
	 * @return
	 */
	protected ApplicationContext getApplicationContext() {
		return applicationContext;
	}

	/*
	 * Manual transactions support
	 */

	protected void startTransaction() {
		startTransaction(new DefaultTransactionDefinition());
	}

	protected void startTransaction(TransactionDefinition transactionDefinition) {
		TransactionContext transactionContext = new TransactionContext(
				platformTransactionManager, transactionDefinition);
		transactionContext.startTransaction();
		TransactionContext.getTransactionsStack().push(transactionContext);
	}

	protected void rollback() {
		endTransaction(true);
	}

	protected void commit() {
		endTransaction(false);
	}

	private void endTransaction(boolean rollback) {
		try {
			TransactionContext transactionContext = TransactionContext.getTransactionsStack().pop();
			transactionContext.endTransaction(rollback);
		} catch (EmptyStackException e) {
			throw e;
		}

	}

	/**
	 * Internal context holder for a specific test method.
	 */
	private static class TransactionContext {

		private static ThreadLocal<Stack<TransactionContext>> transactionsStackHolder = new ThreadLocal<Stack<TransactionContext>>();

		private final PlatformTransactionManager transactionManager;

		private final TransactionDefinition transactionDefinition;

		private TransactionStatus transactionStatus;

		public TransactionContext(
				PlatformTransactionManager transactionManager,
				TransactionDefinition transactionDefinition) {
			this.transactionManager = transactionManager;
			this.transactionDefinition = transactionDefinition;
		}

		public static Stack<TransactionContext> getTransactionsStack() {
			if (transactionsStackHolder.get() == null) {
				transactionsStackHolder.set(new Stack<TransactionContext>());
			}
			return transactionsStackHolder.get();
		}

		public void startTransaction() {
			this.transactionStatus = this.transactionManager
					.getTransaction(this.transactionDefinition);
		}

		public void endTransaction(boolean rollback) {
			if (rollback) {
				this.transactionManager.rollback(this.transactionStatus);
			} else {
				this.transactionManager.commit(this.transactionStatus);
			}
		}
	}

}
