package com.tikal.sample.web.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.context.support.WebApplicationContextUtils;

import com.tikal.sample.domain.model.Actor;
import com.tikal.sample.domain.model.Category;
import com.tikal.sample.domain.model.Product;
import com.tikal.sample.server.service.ProductService;
import com.tikal.sample.server.service.ResultsPage;

public class ProductServiceServlet  extends HttpServlet {

	  private static String[] headers = {"Id",
	        "Asin",
	        "Image",
	        "Title",
	        "Actors",
	        "Categories",
	        "Description"};

	  private static Integer CONFIG_PAGE_SIZE = new Integer("10");
	  private static Integer CONFIG_CURRENT_PAGE = new Integer("1");

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException{
		/*PrintWriter out = response.getWriter();
		String search = request.getParameter("search");
	    out.println("Search Query :"+search);
	    out.print("Total Results :");
	    ResultsPage<Product> productsPage = getProductService().search(search, (short)10,1);
	    out.println(productsPage.getApproximateTotalResults());
	    for (Product product : productsPage.getResults())
	    	out.println(product.getId()+" , "+product.getTitle());*/

		String resultParam = request.getParameter("result");
		if (resultParam != null) {
			response.setContentType("text/html");
		    PrintWriter output = response.getWriter();
			if (resultParam.equals("table")) {
				String searchText = request.getParameter("search");
				String pageParam = request.getParameter("page");
				String pageSizeParam = request.getParameter("pageSize");
				String autoCompletion = request.getParameter("completion");
				Integer page = CONFIG_CURRENT_PAGE;
				Integer pageSize = CONFIG_PAGE_SIZE;
				if (!isEmptyString(searchText)) {
					if (!isEmptyString(autoCompletion) &&
							autoCompletion.equals("1")) {
						searchText+="*";
					}
					try {
						if (!isEmptyString(pageParam)) {
							page = new Integer(pageParam);
						}
						if (!isEmptyString(pageSizeParam)) {
							pageSize = new Integer(pageSizeParam);
						}
					} catch(NumberFormatException nfe) {
						nfe.printStackTrace();
					}
					long start = System.currentTimeMillis();
				    ResultsPage<Product> productsPage = getProductService().search(searchText, pageSize.shortValue(), page.intValue());
				    long time = (System.currentTimeMillis()-start)/10;
                	float secTime = time/(100f);
					output.print(getArrayDisplay(productsPage, secTime));
				}
			} else if (resultParam.equals("headers")) {
				output.print("[");
				for (int i=0; i<headers.length; i++) {
					output.print("\"" + headers[i] + "\"");
					if ( i < headers.length - 1) {
						output.print(",");
					}
				}
				output.print("]");
			}
		}

	}

	private ProductService getProductService(){
		return (ProductService) WebApplicationContextUtils.getRequiredWebApplicationContext(getServletContext()).getBean("productService");
	}

	 public void doPost(HttpServletRequest req, HttpServletResponse res)
		throws ServletException, IOException {
		 doGet(req, res);
	 }


	 private String getCompletionDisplay(Object object) {
		 return null;
	 }

	 private String getArrayDisplay(Object object, float responseTime) {
		 String output = "<root>";
		 if (object == null) return output;
		 ResultsPage<Product> productsPage = (ResultsPage<Product>)object;
		 if (productsPage != null) {
			 List<Product> list = productsPage.getResults();
			 if (list != null) {
				 int approximateTotalResults = productsPage.getApproximateTotalResults();
				 output += "<total>";
				 output += "<time>" + String.valueOf(responseTime) + "</time>";
				 output += "<pagecount>" + list.size() + "</pagecount>";
				 output += "<results>" + String.valueOf(approximateTotalResults)+ "</results>";
				 output += "</total>";
				 for (int i = 0; i < list.size(); i++) {
					 Product product = productsPage.getResults().get(i);
					 output += "<row>";
					 output  += "<" + headers[0] + ">" + product.getId() + "</" + headers[0] + ">" ;
					 output  += "<" + headers[1] + ">" + product.getASIN() + "</" + headers[1] + ">" ;
					 output  += "<" + headers[2] + "><![CDATA[" + product.getImageURL() + "]]></" + headers[2] + ">" ;
					 output  += "<" + headers[3] + "><![CDATA[" + product.getTitle() + "]]></" + headers[3] + ">" ;
					 output  += "<" + headers[4] + "><![CDATA[" + getActorsDisplay(product.getActors()) + "]]></" + headers[4] + ">" ;
					 output  += "<" + headers[5] + "><![CDATA[" + getCategoriesDisplay(product.getCategories()) + "]]></" + headers[5] + ">" ;
					 output  += "<" + headers[6] + "><![CDATA[" + product.getDescription() + "]]></" + headers[6] + ">" ;
					 output += "</row>";
				 }
				 output += "</root>";
			 }
		 }
		 return output;
	 }

	 private static String getActorsDisplay(Set<Actor> actors) {
		 String result = "";
		 if (actors == null) return result;
		 Iterator itr = actors.iterator();
		 for (int i=0; i<actors.size(); i++) {
			 Actor actor = (Actor)itr.next();
			 result += actor.getName();
			 if (itr.hasNext()) {
				 result += "; ";
			 }
		 }
		 return result;
	 }

	 private static String getCategoriesDisplay(Set<Category> categories) {
		 String result = "";
		 if (categories == null) return result;
		 Iterator itr = categories.iterator();
		 for (int i=0; i<categories.size(); i++) {
			 Category category = (Category)itr.next();
			 result += category.getName();
			 if (itr.hasNext()) {
				 result += "; ";
			 }
		 }
		 return result;
	 }

	 private static boolean isEmptyString(String value) {
		 if ( value == null || (value != null && value.trim().equals("")) ) {
			 return true;
		 }
		 return false;
	 }
}
