package com.tikal.sample.web.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.context.support.WebApplicationContextUtils;

import com.tikal.sample.domain.model.Actor;
import com.tikal.sample.domain.model.Category;
import com.tikal.sample.domain.model.Product;
import com.tikal.sample.server.service.ProductService;
import com.tikal.sample.server.service.ResultsPage;

public class ThinProductServiceServlet  extends HttpServlet {

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException{

		short pageSize = (short)10;
		PrintWriter out = response.getWriter();
		String pageNo = request.getParameter("pageNo");
		int pageNumber = (pageNo == null)?1:Integer.parseInt(pageNo);
		String search = request.getParameter("search");
		if(search == null){
			out.println("Please provide input in the url.");
			return;
		}

		ResultsPage<Product> productsPage;

		String advanced = request.getParameter("simple");
		long start = System.currentTimeMillis();
		if(advanced!=null && advanced.equals("true"))
			productsPage  = getProductService().simpleSearch(search,pageSize ,pageNumber);
	    else
	    	productsPage = getProductService().search(search,pageSize ,pageNumber);
	    long time = (System.currentTimeMillis()-start)/10;
    	float secTime = time/(100f);

    	out.println("<html><body>");

    	if(productsPage.getResults().isEmpty())
    		out.print("No results found");
    	else{
    		int first = (pageNumber-1)*pageSize+1;
    		int last = Math.min(productsPage.getResults().size(),pageNumber*pageSize);
	    	out.print("Results "+first+" - "+last);
		    out.print(" out of - "+productsPage.getApproximateTotalResults());
		    out.println(" for <b>"+search+"</b> ("+secTime+" sec)\n\n");
    	}

    	out.println("<table>");
	    for (Product product : productsPage.getResults()){
	    	out.println("<tr>");
	    	out.println("<td>"+product.getId()+"</td>" +
	    				"<td>"+product.getTitle()+"</td>"+
	    				"<td>"+getCategories(product)+"</td>"+
	    				"<td>"+getActors(product)+"</td>"+
	    				//"<td>"+product.getDescription()+"</td>"+
	    				"<td><img src=\""+product.getImageURL()+"\"/></td>");
	    	out.println("<tr>");
	    }
	    out.println("</table>");

	    out.println("</body></html>");
	}

	private String getCategories(Product product){
		StringBuilder builder = new StringBuilder();
		for (Category category : product.getCategories())
			builder.append(category.getName()+" ");
		return builder.toString();
	}


	private String getActors(Product product){
		StringBuilder builder = new StringBuilder();
		for (Actor actor : product.getActors())
			builder.append(actor.getName());
		return builder.toString();
	}

	private ProductService getProductService(){
		return (ProductService) WebApplicationContextUtils.getRequiredWebApplicationContext(getServletContext()).getBean("productService");
	}
}
