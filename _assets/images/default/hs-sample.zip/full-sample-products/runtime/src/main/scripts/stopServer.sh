#! /bin/bash
source ./setenv.sh default
cd ${server_bin}
./shutdown.bat -c default -S

