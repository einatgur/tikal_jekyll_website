#!/bin/sh

hs_home=`cd ..;pwd`

export hs_home

export JAVA_HOME=${hs_home}/jdk
export PATH=$JAVA_HOME/bin:$PATH


if [ -z "$1" ] ; then
	export hs_home
	return
fi

# ------------------------------------------------------------------
# set the properties in conf/$1.properties as system properties
# ------------------------------------------------------------------
JAVAOPTS=`cat ${hs_home}/conf/$1.properties | sed s:'${hs_home}':${hs_home}:g`
for i in ${JAVAOPTS}
do
    # if the file content is empty, then it will return the input string
    echo $i | grep '=' > /dev/null
    has_eq=$?
    echo $i | grep -Ee '^-XX:' > /dev/null
    has_xx=$?
    #echo $i | grep -Ee '^#' > /dev/null
    #has_comment=$?
    # ignore the comment lines
    #if [ $has_comment -eq 0 ]; then
    if [ $has_eq -eq 0 ] && [ $has_xx -ne 0  ]; then
       #echo "-D$i"
       JAVA_OPTS="$JAVA_OPTS -D$i"
    else
       #echo "$i"
       JAVA_OPTS="$JAVA_OPTS $i"
    fi
   #fi
done


# ------------------------------------------------------------------
# set the bind address
# ------------------------------------------------------------------

if [ -z "$2" ] ; then
	#echo no bind address
	bind_address="0.0.0.0"
else
	#echo $2
	bind_address="$2"
fi
export bind_address

# ------------------------------------------------------------------
# set the debug options
# ------------------------------------------------------------------
if [ -n "${XPR_DEBUG_PORT}" ]; then
    JAVA_OPTS="${JAVA_OPTS} -Xdebug -Xrunjdwp:server=y,transport=dt_socket,address=${XPR_DEBUG_PORT},suspend=${SUSPEND_UNTIL_DEBUG_ATTACHE} "
fi

export JAVA_OPTS

export server_bin=${hs_home}/jboss/bin
