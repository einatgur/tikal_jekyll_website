#! /bin/bash
source ./setenv.sh default
cd ${server_bin}
./run.sh -c default -b ${bind_address}

