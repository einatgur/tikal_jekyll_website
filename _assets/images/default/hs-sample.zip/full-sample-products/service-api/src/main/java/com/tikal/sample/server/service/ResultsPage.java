package com.tikal.sample.server.service;

import java.util.List;

public interface ResultsPage<T> {
	List<T> getResults();
	int getApproximateTotalResults();
}
