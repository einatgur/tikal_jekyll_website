package com.tikal.sample.server.service;

import com.tikal.sample.domain.model.Product;

public interface ProductService {
	// Full Text Search methods

	ResultsPage<Product> simpleSearch(String searchQuery,short pageSize,int pageNo) ;

	ResultsPage<Product> search(String searchQuery, short pageSize,int pageNo);











	//Some more business methods
	ResultsPage<Product>  searchFromDB(String searchQuery,short pageSize,int pageNo) ;

	Product createProduct(Product product);

	Product updateProduct(Product product);

	Product findProductById(long id);

}
