/*
* JBoss, Home of Professional Open Source
* Copyright 2008, Red Hat Middleware LLC, and individual contributors
* by the @authors tag. See the copyright.txt in the distribution for a
* full listing of individual contributors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
* http://www.apache.org/licenses/LICENSE-2.0
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
package com.tikal.sample.domain.model;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.FieldBridge;
import org.hibernate.search.annotations.Index;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.IndexedEmbedded;
import org.hibernate.search.annotations.Store;

import com.tikal.sample.domain.bridge.ParameterizedPaddedRoundedPriceBridge;


@Entity
@Table(name = "products")
@Indexed
public class Product implements Serializable {
	@Id
	@GeneratedValue
	@Column(name = "prod_id")
	private Long id;

	@Column(length = 16)
	@Field(index = Index.UN_TOKENIZED)
	private String asin;

	@Column( length = 100)
	@Field(store = Store.YES)
	private String title;

	@Column(length = 4096)
	@Field
	private String description;

	@Column(name="image_url",length = 256)
	private String imageURL;

	@Column(nullable = false)
	@Field(index = Index.UN_TOKENIZED, store = Store.YES)
	@FieldBridge(impl= ParameterizedPaddedRoundedPriceBridge.class)
	private double price;

	@ManyToMany
	@JoinTable(name = "product_actor", joinColumns = @JoinColumn(name = "prod_id"), inverseJoinColumns = @JoinColumn(name = "actor_id"))
	@IndexedEmbedded
	private Set<Actor> actors;

	@ManyToMany
	@JoinTable(name = "product_category", joinColumns = @JoinColumn(name = "prod_id"), inverseJoinColumns = @JoinColumn(name = "category_id"))
	@IndexedEmbedded
	private Set<Category> categories;


	public Long getId() {
		return id;
	}

	@SuppressWarnings("unused")
	private void setId(long id) {
		this.id = id;
	}


	public String getASIN() {
		return asin;
	}

	public void setASIN(String asin) {
		this.asin = asin;
	}


	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}


	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}


	public Set<Actor> getActors() {
		return actors;
	}

	public void setActors(Set<Actor> actors) {
		this.actors = actors;
	}


	public Set<Category> getCategories() {
		return categories;
	}

	public void setCategories(Set<Category> categories) {
		this.categories = categories;
	}


	public String getImageURL() {
		return imageURL;
	}

	public void setImageURL(String imageURL) {
		this.imageURL = imageURL;
	}


	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Product("+title+")";
	}


}
