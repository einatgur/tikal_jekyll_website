package com.tikalk.am.util.web.jmx;

import java.io.IOException;

import javax.management.MBeanParameterInfo;
import javax.management.MBeanServerConnection;

import org.springframework.jmx.support.MBeanServerConnectionFactoryBean;

public class JmxUtils {

	public static MBeanServerConnection getMBeanServerConnection(String url) throws IOException {
		MBeanServerConnectionFactoryBean cf = new MBeanServerConnectionFactoryBean();
		cf.setServiceUrl(url);
		cf.afterPropertiesSet();
		MBeanServerConnection conn = (MBeanServerConnection)cf.getObject();
		return conn;
	}

	public static String parseSignature(MBeanParameterInfo[] sig) {
		StringBuilder bldr = new StringBuilder();
		for(MBeanParameterInfo param : sig) {
			if(bldr.length() > 0) {
				bldr.append(",");
			}
			bldr.append(param.getType());
		}
		return bldr.toString();
	}
}
