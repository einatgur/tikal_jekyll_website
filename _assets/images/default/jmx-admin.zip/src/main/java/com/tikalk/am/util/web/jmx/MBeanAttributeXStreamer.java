package com.tikalk.am.util.web.jmx;

import java.io.File;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.converters.Converter;
import com.thoughtworks.xstream.converters.MarshallingContext;
import com.thoughtworks.xstream.converters.SingleValueConverter;
import com.thoughtworks.xstream.converters.UnmarshallingContext;
import com.thoughtworks.xstream.io.HierarchicalStreamReader;
import com.thoughtworks.xstream.io.HierarchicalStreamWriter;

public class MBeanAttributeXStreamer extends XStream {
	private DateFormat format = new SimpleDateFormat("yyyy-MM-dd");

	public MBeanAttributeXStreamer() {
		//alias("null", ;)

		registerConverter(new SingleValueConverter() {
			@Override
			public Object fromString(String str) {
				return new Long(str.substring(0, str.indexOf('(')));
			}
			@Override
			public String toString(Object obj) {
				return String.valueOf(obj) + "(" + format.format(new Date((Long)obj)) + ")";
			}
			@Override
			public boolean canConvert(Class type) {
				return Long.class.equals(type);
			}
		});

		// drops all unwanted serializations
		registerConverter(new Converter() {
			@Override
			public void marshal(Object source, HierarchicalStreamWriter writer,
					MarshallingContext context) {
			}
			@Override
			public Object unmarshal(HierarchicalStreamReader reader,
					UnmarshallingContext context) {
				return null;
			}
			@Override
			public boolean canConvert(Class type) {
				return !(Map.class.isAssignableFrom(type) ||
						List.class.isAssignableFrom(type) ||
						Collection.class.isAssignableFrom(type) ||
						Byte.class.isAssignableFrom(type) ||
						Short.class.isAssignableFrom(type) ||
						Integer.class.isAssignableFrom(type) ||
						Long.class.isAssignableFrom(type) ||
						Float.class.isAssignableFrom(type) ||
						Double.class.isAssignableFrom(type) ||
						String.class.isAssignableFrom(type) ||
						Timestamp.class.isAssignableFrom(type) ||
						File.class.isAssignableFrom(type) ||
						Throwable.class.isAssignableFrom(type) ||
						StackTraceElement.class.isAssignableFrom(type) ||
						//StackTraceElement[].class.isAssignableFrom(type) ||
						type.isArray() ||
						type.getName().startsWith("com.vmware"));
			}
		});
	}
}
