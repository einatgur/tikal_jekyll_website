package com.tikalk.am.util.web.jmx;

import java.io.File;
import java.io.IOException;

import org.dom4j.DocumentException;
import org.dom4j.io.SAXReader;
import org.springframework.core.io.ClassPathResource;

public class MBeanValueConverter {

	private static final String CLASSPATH_RESOURCE_IDENTIFIER = "resource:";
	private static final String UTF8_CHARSET = "UTF-8";

	public static Object convert(String type, String value) throws DocumentException, ClassNotFoundException, IOException {
		Object result = null;
		if("java.lang.String".equals(type)) {
			result = value;
		}
		else if("java.lang.Integer".equals(type) || "int".equals(type)) {
			result = new Integer(value);
		}
		else if("java.lang.Long".equals(type) || "long".equals(type)) {
			result = new Long(value);
		}
		else if("java.lang.Float".equals(type) || "float".equals(type)) {
			result = new Float(value);
		}
		else if("java.lang.Double".equals(type) || "double".equals(type)) {
			result = new Double(value);
		}
		else if("java.lang.Byte".equals(type) || "byte".equals(type)) {
			result = new Byte(value);
		}
		else if("java.lang.Short".equals(type) || "short".equals(type)) {
			result = new Short(value);
		}
		else if("java.lang.Boolean".equals(type) || "boolean".equals(type)) {
			result = new Boolean(value);
		}
		else if("[B".equals(type)) { /// byte array
			result = value.getBytes(UTF8_CHARSET);
		}
		// Surprises!
		else if("org.dom4j.Document".equals(type)) {
			SAXReader reader = new SAXReader();
			result = reader.read(new java.io.ByteArrayInputStream(value.getBytes(UTF8_CHARSET)));
		}
		else if("java.io.File".equals(type)) {
			if(value.startsWith(CLASSPATH_RESOURCE_IDENTIFIER)) {
				result = new ClassPathResource(value.substring(CLASSPATH_RESOURCE_IDENTIFIER.length())).getFile();
			}
			else {
				result = new File(value);
			}
		}
		else {
			// Enumerations
			Class clz = Class.forName(type);
			if (clz.isEnum()) {
				Object[] consts = clz.getEnumConstants();
				for(Object o : consts) {
					if(o.toString().equals(value)) {
						result = o;
						break;
					}
				}
			}
		}
		// other supported types?
		return result;
	}
}
