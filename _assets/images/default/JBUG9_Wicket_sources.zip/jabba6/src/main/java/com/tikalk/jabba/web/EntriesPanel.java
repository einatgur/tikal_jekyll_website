package com.tikalk.jabba.web;

import java.text.DateFormat;
import java.util.List;

import org.apache.wicket.PageParameters;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.link.BookmarkablePageLink;
import org.apache.wicket.markup.html.list.ListItem;
import org.apache.wicket.markup.html.list.ListView;
import org.apache.wicket.markup.html.panel.Panel;

import com.tikalk.jabba.model.Jabba;

/**
 * @author ittayd
 */
public class EntriesPanel extends Panel {

	public EntriesPanel(String id, List entries) {
		super(id);
    	final DateFormat format = DateFormat.getDateInstance();

		add(new ListView("entries", entries){
			@Override
			protected void populateItem(ListItem item) {
				final Jabba.Entry entry = (Jabba.Entry)item.getModelObject();
				item.add(new Label("date", format.format(entry.getDate())));

				PageParameters params = Common.createParameters(entry);

        item.add(new BookmarkablePageLink("titleLink", EntryPage.class, params).
            add(new Label("title", entry.getTitle())));

			}


    	});

	}

}

