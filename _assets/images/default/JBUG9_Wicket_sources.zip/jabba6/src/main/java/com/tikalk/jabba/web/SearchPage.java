package com.tikalk.jabba.web;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.wicket.MarkupContainer;
import org.apache.wicket.PageParameters;
import org.apache.wicket.ajax.AjaxRequestTarget;
import org.apache.wicket.ajax.markup.html.form.AjaxButton;
import org.apache.wicket.datetime.markup.html.form.DateTextField;
import org.apache.wicket.extensions.ajax.markup.html.autocomplete.AutoCompleteTextField;
import org.apache.wicket.extensions.yui.calendar.DatePicker;
import org.apache.wicket.markup.html.WebPage;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.form.Form;
import org.apache.wicket.markup.html.form.StatelessForm;
import org.apache.wicket.model.CompoundPropertyModel;
import org.apache.wicket.model.PropertyModel;

import com.tikalk.jabba.model.Jabba;

/**
 * @author ittayd
 */
public class SearchPage extends WebPage {

	private static class SearchTerm implements Serializable{
		Date date;
		String title;
	}

	public SearchPage() {
		super();

		Label label = new Label("results", "Enter some values in form");
		label.setOutputMarkupId(true);
		final String id = label.getMarkupId();
		add(label);

		final SearchTerm st = new SearchTerm();
		Form form = new StatelessForm("search", new CompoundPropertyModel(st));
		add(form);

	  DateTextField dateSearch = DateTextField.forShortStyle("date");
		dateSearch.add(new DatePicker());
		form.add(dateSearch);

		AutoCompleteTextField titleSearch = new AutoCompleteTextField("title") {

      @Override
      protected Iterator getChoices(String input) {
        return getEntryTitlesByPrefix(input);
      }

      private Iterator getEntryTitlesByPrefix(String input) {
        List list = new ArrayList();
        for (Iterator iter = getEntriesByPrefix(input).iterator();iter.hasNext();){
          list.add(((Jabba.Entry)iter.next()).getTitle());
        }
        return list.iterator();
      }

		};
		form.add(titleSearch);

		form.add(new AjaxButton("submit") {

			@Override
			protected void onSubmit(AjaxRequestTarget target, Form form) {
				EntriesPanel results = new EntriesPanel("results", getEntries(st));
				SearchPage.this.replace(results);
				target.addComponent(results, id);
			}


		});
	}

	protected List getEntries(final SearchTerm st) {
    if (st.title != null) {
      return getEntriesByPrefix(st.title);
    }
    return getEntries(st.date);
  }
	protected List getEntries(Date date) {
	  return Jabba.getInstance().getEntries(date);
	}

  protected List getEntriesByPrefix(String prefix) {
    return Jabba.getInstance().searchEntriesByPrefix(prefix);
  }

}

