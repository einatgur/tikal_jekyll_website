package com.tikalk.jabba.web;

import java.text.DateFormat;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;

import org.apache.wicket.PageParameters;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.basic.MultiLineLabel;
import org.apache.wicket.markup.html.link.BookmarkablePageLink;
import org.apache.wicket.markup.html.link.Link;
import org.apache.wicket.markup.html.list.ListItem;
import org.apache.wicket.markup.html.list.ListView;
import org.apache.wicket.markup.html.WebPage;

import com.tikalk.jabba.model.Jabba;

/**
 * Homepage
 */
public class HomePage extends WebPage {

	private static final long serialVersionUID = 1L;

	// TODO Add any page properties or variables here

    /**
	 * Constructor that is invoked when page is invoked without a session.
	 *
	 * @param parameters
	 *            Page parameters
	 */
    public HomePage(final PageParameters parameters) {
    	final DateFormat format = DateFormat.getDateInstance();
    	add(new ListView("entries", Jabba.getInstance().getEntries()){
			@Override
			protected void populateItem(ListItem item) {
				final Jabba.Entry entry = (Jabba.Entry)item.getModelObject();
				item.add(new Label("date", format.format(entry.getDate())));

				PageParameters params = new PageParameters();
				params.add("title", entry.getTitle());
				params.add("year", String.valueOf(entry.getDate().getYear() + 1900));
				params.add("month", String.valueOf(entry.getDate().getMonth()));

				item.add(new BookmarkablePageLink("titleLink", EntryPage.class, params).
          add(new Label("title", entry.getTitle())));

			}
    	});

    }
}
