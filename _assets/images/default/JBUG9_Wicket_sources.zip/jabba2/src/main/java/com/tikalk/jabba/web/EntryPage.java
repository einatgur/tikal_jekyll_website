package com.tikalk.jabba.web;

import java.util.Locale;

import org.apache.wicket.markup.html.WebPage;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.basic.MultiLineLabel;
import org.apache.wicket.markup.html.list.ListItem;
import org.apache.wicket.markup.html.list.ListView;
import org.apache.wicket.model.CompoundPropertyModel;
import org.apache.wicket.util.convert.IConverter;
import org.apache.wicket.util.convert.converters.DateConverter;

import com.tikalk.jabba.model.Jabba.Entry;

/**
 * @author ittayd
 */
public class EntryPage extends WebPage {

	public EntryPage(Entry entry) {
		super();
		setModel(new CompoundPropertyModel(entry));
		add(new Label("head-title", entry.getTitle()));
		add(new Label("title"));
		add(new Label("date") {
			private static final long serialVersionUID = 1L;

			public IConverter getConverter(Class type) {
				return new DateConverter();
			}
		});
		add(new MultiLineLabel("text"));
		add(new ListView("comments"){

			@Override
			protected void populateItem(ListItem item) {
				item.add(new MultiLineLabel("comment", item.getModel()));
			}
		});
	}

}

