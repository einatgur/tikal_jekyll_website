package com.tikalk.jabba.model;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

public class Jabba {
	public static class Entry {

		private List<String> comments;
		private String text;
		private String title;
		private Date date;

		public Entry(Date date, String title, String text, String... comments) {
			this.date = date;
			this.title = title;
			this.text = text;
			this.comments = new ArrayList<String>();
			this.comments.addAll(Arrays.asList(comments));
		}

		public void addComment(String text) {
			this.comments.add(text);
		}

		public List<String> getComments() {
			return comments;
		}

		public String getText() {
			return text;
		}

		public String getTitle() {
			return title;
		}

		public Date getDate() {
			return date;
		}

	}

	private static Jabba instance = new Jabba();

	public static Jabba getInstance() {
		return instance;
	}

	private List<Entry> entries = new ArrayList<Entry>();

	private Jabba() {
		add(new Entry(new Date(107, 11, 1), "Welcome to my blog", "This is the first post", "Great post!", "What are you talking about"));
		add(new Entry(new Date(), "Second post", "This is the secong post", "You're repeating yourself...", "Lame!"));
	}

	public List<Entry> getEntries() {
		return entries;
	}

	public void add(Entry entry) {
		entries.add(entry);
	}
}
