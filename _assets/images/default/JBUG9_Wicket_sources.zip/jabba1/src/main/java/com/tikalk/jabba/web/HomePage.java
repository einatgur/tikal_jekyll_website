package com.tikalk.jabba.web;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.List;

import org.apache.wicket.PageParameters;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.basic.MultiLineLabel;
import org.apache.wicket.markup.html.list.ListItem;
import org.apache.wicket.markup.html.list.ListView;
import org.apache.wicket.markup.html.WebPage;

import com.tikalk.jabba.model.Jabba;
import com.tikalk.jabba.model.Jabba.Entry;

/**
 * Homepage
 */
public class HomePage extends WebPage {

  private static final long serialVersionUID = 1L;

  // TODO Add any page properties or variables here

  /**
   * Constructor that is invoked when page is invoked without a session.
   *
   * @param parameters
   *          Page parameters
   */
  public HomePage(final PageParameters parameters) {
    super(parameters);
    add(new ListView("entries", getEntries()) {
      @Override
      protected void populateItem(ListItem item) {
        Jabba.Entry entry = (Jabba.Entry) item.getModelObject();
        item.add(new Label("date", format(entry)));
        item.add(new Label("title", entry.getTitle()));
      }

      private String format(Jabba.Entry entry) {
        DateFormat format = DateFormat.getDateInstance();
        return format.format(entry.getDate());
      }
    });

  }

  private List getEntries() {
    return Jabba.getInstance().getEntries();
  }
}
