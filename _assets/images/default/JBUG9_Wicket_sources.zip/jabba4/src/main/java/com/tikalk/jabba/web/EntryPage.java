package com.tikalk.jabba.web;

import java.io.Serializable;
import java.util.Locale;

import org.apache.wicket.PageParameters;
import org.apache.wicket.markup.html.WebPage;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.basic.MultiLineLabel;
import org.apache.wicket.markup.html.form.Form;
import org.apache.wicket.markup.html.form.StatelessForm;
import org.apache.wicket.markup.html.form.TextArea;
import org.apache.wicket.markup.html.list.ListItem;
import org.apache.wicket.markup.html.list.ListView;
import org.apache.wicket.model.CompoundPropertyModel;
import org.apache.wicket.model.PropertyModel;
import org.apache.wicket.util.convert.IConverter;
import org.apache.wicket.util.convert.converters.DateConverter;

import com.tikalk.jabba.model.Jabba;
import com.tikalk.jabba.model.Jabba.Entry;

/**
 * @author ittayd
 */
public class EntryPage extends WebPage {

	class Comment implements Serializable {
		String comment;
	}

	private Comment comment = new Comment();
	private ListView commentsListView;

	public EntryPage(final PageParameters params) {
		super(params);
		if (params.size() == 0) {
			setResponsePage(HomePage.class);
			return;
		}
		final Entry entry = Jabba.getInstance().getEntry(params.getString("title"));
		addEntryComponents(entry);

		add(new StatelessForm("addComment") {
			{
				add(new TextArea("comment", new PropertyModel(comment, "comment")));
			}

			@Override
			protected void onSubmit() {
				entry.addComment(comment.comment);
				commentsListView.modelChanged();
				setResponsePage(EntryPage.class, Common.createParameters(entry));
			}


		});


	}

	private void addEntryComponents(Entry entry) {
		setModel(new CompoundPropertyModel(entry));
		add(new Label("head-title", entry.getTitle()));
		add(new Label("title"));
		add(new Label("date") {
			private static final long serialVersionUID = 1L;

			public IConverter getConverter(Class type) {
				return new DateConverter();
			}
		});
		add(new MultiLineLabel("text"));
		add(commentsListView = new ListView("comments"){

			@Override
			protected void populateItem(ListItem item) {
				item.add(new MultiLineLabel("comment", item.getModel()));
			}
		});
	}

}

