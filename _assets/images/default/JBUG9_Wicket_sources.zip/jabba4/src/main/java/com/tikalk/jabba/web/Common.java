package com.tikalk.jabba.web;

import org.apache.wicket.PageParameters;

import com.tikalk.jabba.model.Jabba;

public class Common {
	public static PageParameters createParameters(final Jabba.Entry entry) {
		PageParameters params = new PageParameters();
		params.add("title", entry.getTitle());
		params.add("year", String.valueOf(entry.getDate().getYear() + 1900));
		params.add("month", String.valueOf(entry.getDate().getMonth()));
		return params;
	}
}
