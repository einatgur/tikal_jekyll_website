package com.tikal.factorial;

import java.io.Serializable;
import java.util.Collection;
import java.util.LinkedList;

@SuppressWarnings("serial")
public class Range implements Serializable {
	int start;
	int end;

	public Range(int start, int end) {
		this.start = start;
		this.end = end;
	}

	public int getStart() {
		return start;
	}

	public int getEnd() {
		return end;
	}

	public void setStart(int start) {
		this.start = start;
	}

	public void setEnd(int end) {
		this.end = end;
	}

	@Override
	public String toString() {
		return "{"+start+","+end+"}";
	}

	public static Collection<Range> split(int n, int noOfRanges) {
		LinkedList<Range> ranges = new LinkedList<Range>();
		if(n==1){
			ranges.add(new Range(1,1));
			return ranges;
		}
		if(n<noOfRanges)
			noOfRanges = n;
		int interval = n / noOfRanges;
		for (int i=0; i < n; i=i+interval )
			ranges.add(new Range(i+1,i+interval));
		Range last = ranges.getLast();
		last.setEnd(n);
		return ranges;
	}

}
