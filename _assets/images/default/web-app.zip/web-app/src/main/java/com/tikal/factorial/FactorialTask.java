package com.tikal.factorial;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.apache.log4j.Logger;
import org.gridgain.grid.GridException;
import org.gridgain.grid.GridJob;
import org.gridgain.grid.GridJobAdapter;
import org.gridgain.grid.GridJobResult;
import org.gridgain.grid.GridTaskSplitAdapter;

@SuppressWarnings("serial")
public class FactorialTask extends GridTaskSplitAdapter<Integer> {
	private static org.apache.log4j.Logger log = Logger.getLogger(FactorialTask.class);
	@Override
	protected Collection<? extends GridJob> split(int gridSize, Integer n) throws GridException {

		int noOfJobs = gridSize;
		List<GridJobAdapter<Range>> jobs = new ArrayList<GridJobAdapter<Range>>(noOfJobs);

		final Collection<Range> ranges = Range.split(n, noOfJobs);
		log.info("******* Spliting into ranges:"+ranges);
		for (final Range range : ranges)
			jobs.add(new RangeFactorialCalculateJob(range));
		return jobs;
	}

	@Override
	public Object reduce(List<GridJobResult> results) throws GridException {
		log.info("******* reducing "+results.size()+" results");
		BigInteger n = BigInteger.ONE;
		for (GridJobResult gridJobResult : results)
			n = n.multiply(((BigInteger) gridJobResult.getData()));
		return n;
	}
}
