package com.tikal.factorial;

import java.io.Serializable;

import org.gridgain.grid.GridException;
import org.gridgain.grid.GridJobAdapter;

@SuppressWarnings("serial")
public class RangeFactorialCalculateJob extends GridJobAdapter<Range>{

	public RangeFactorialCalculateJob(Range range){
		super(range);
	}

	@Override
	public Serializable execute() throws GridException {
		return Factorial.factorialFregment(getArgument());
	}

}
