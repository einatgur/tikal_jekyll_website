package com.tikal.factorial;

import java.math.BigInteger;

import org.apache.log4j.Logger;
import org.gridgain.grid.GridFactory;


public class Factorial {
	 private static org.apache.log4j.Logger log = Logger.getLogger(Factorial.class);
	public static BigInteger factorial(int n){
		try {
			return (BigInteger) GridFactory.getGrid().execute(FactorialTask.class.getName(), n).get();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public static BigInteger factorialFregment(Range range){
		log.info("******Computing factorialFregment for range:"+range+"...");
		BigInteger n = BigInteger.ONE;
		for (int i = range.getStart(); i <= range.getEnd() ; i++)
			n = n.multiply(BigInteger.valueOf(i));
		log.info("******Finished Computing factorialFregment for range:"+range+"...");
		return n;
	}
}
