import java.math.BigInteger;

import junit.framework.TestCase;

import org.gridgain.grid.GridException;
import org.gridgain.grid.GridFactory;

import com.tikal.factorial.Factorial;
import com.tikal.factorial.Range;


public class FactorialTest extends TestCase{

	public void testFactorial() throws GridException{
		int n = 40000;
		GridFactory.start();
		try{
			//assertEquals(new BigInteger("120"),Factorial.factorial(5));
			BigInteger f = Factorial.factorial(n);
			System.out.println();
			System.out.println(f.toString().length());
			assertEquals(Factorial.factorialFregment(new Range(1,n)),f);
		} finally{
			GridFactory.stop(true);
		}
	}
}
