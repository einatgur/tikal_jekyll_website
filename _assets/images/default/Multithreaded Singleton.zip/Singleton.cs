﻿using System;

namespace $rootnamespace$
{
    public sealed class $safeitemname$
    {
        private static volatile $safeitemname$ instance;
        private static object syncRoot = new object();

        private $safeitemname$()
        {
        }

        public static $safeitemname$ Instance
        {
            get
            {
                if (instance == null)
                {
                    lock (syncRoot)
                    {
                        if (instance == null)
                            instance = new $safeitemname$();
                    }
                }

                return instance;
            }
        }
    }
}
